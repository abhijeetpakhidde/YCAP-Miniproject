module Banking_management_system {
	requires java.sql;
}